Put the real ebook file here, e.g.:

  protected/100-ai-tools-ebook.pdf

This folder is intentionally NEVER served as static/public content by
the backend (see backend/server.js — only "frontend/" is served statically).
The only way to retrieve this file is through GET /api/download?token=...,
which requires a valid, signed, time-limited token issued after a
verified Razorpay payment (see backend/controllers/paymentController.js).

The exact path is configurable via EBOOK_FILE_PATH in backend/.env.
